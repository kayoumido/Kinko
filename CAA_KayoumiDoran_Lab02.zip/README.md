# CAA - Lab 02: Encrypted vault

<p align="center">
<img src="docs/cover.jpg" width="500">
</p>

> Author: Doran Kayoumi
> Teacher: Alexandre Duc
> ssistant. Nathan Séville

## About Kinkō.

`Kinkō` was developed as a laboratory at the [HEIG-VD](https://heig-vd.ch/) in the academic year of 2020-2021. The purpose of the laboratory is to implement an online vault to store encrypted files.

## Getting started

**Prerequisites**	

- [Docker](https://docs.docker.com/install/) (v19.03.8-cd)
- [Docker-compose](https://docs.docker.com/compose/install/) (v1.25.4)

**Start Kinko**

First thing you need to do, is startup the database.

```bash
$ docker-compose up -d
```

Now you can start the prototype:

```bash
$ cargo run
```

Since this is only a prototype, it will simulate the `Kinkō` architecture and perform the following:

* Authentication
* Upload a file
* Download a file
